# Experimental iOS 26 compatibility pass

This build removes the obsolete `AVExternalDevice.currentCarPlay()` connection
gate, queues URLs until the CarPlay scene is connected, makes private framework
lookups fail safely, and updates the web view layout when the head-unit size
changes.

It does not create or grant a CarPlay entitlement. The original application
still depends on private entitlements and installation support equivalent to
the original TrollStore environment. A normally re-signed IPA may install on
the phone while being excluded from the CarPlay home screen by iOS.
